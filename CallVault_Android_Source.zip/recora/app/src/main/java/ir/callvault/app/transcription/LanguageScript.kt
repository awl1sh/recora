/*
 * CallVault: FOSS call recording, self-contained over embedded ADB
 *  Copyright (C) 2026-present The CallVault Authors
 *  This software is licensed under the GNU General Public License v3 or later, with additional terms as permitted under Section 7.
 *  The full license text is available in the LICENSE file at the root of this project.
 *  This software is distributed WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

package ir.callvault.app.transcription

/**
 * Which alphabet each offered transcription language is written in.
 *
 * One table, because two rules read it and must agree: [TranscriptionPrompt] will not prime whisper with
 * a name in another script, and [WrongScriptRetry] treats a transcript in another script as a failed
 * decode. Only the languages that are NOT Latin are listed; every other entry in
 * [TranscriptionLanguageChoice.SUPPORTED] is Latin today.
 */
object LanguageScript {

    private val NON_LATIN = mapOf(
        "he" to Character.UnicodeScript.HEBREW,
        "ar" to Character.UnicodeScript.ARABIC,
        "ru" to Character.UnicodeScript.CYRILLIC,
        "uk" to Character.UnicodeScript.CYRILLIC,
        "zh" to Character.UnicodeScript.HAN,
        "el" to Character.UnicodeScript.GREEK,
        // Persian is written in the Arabic script, so a Latin transcript under a Persian pin is caught
        // the same way. Telling Persian from Arabic is not this table's job — see SummaryLanguage.
        "fa" to Character.UnicodeScript.ARABIC,
        // Urdu too (Nastaliq is a style of the Arabic script, not a script of its own).
        "ur" to Character.UnicodeScript.ARABIC,
    )

    fun of(language: String): Character.UnicodeScript = NON_LATIN[language] ?: Character.UnicodeScript.LATIN

    /** Whether [language] is written in something other than Latin letters — the only case a script can catch. */
    fun isNonLatin(language: String): Boolean = language in NON_LATIN
}
