/*
 * CallVault: FOSS call recording, self-contained over embedded ADB
 *  Copyright (C) 2026-present The CallVault Authors
 *  This software is licensed under the GNU General Public License v3 or later, with additional terms as permitted under Section 7.
 *  The full license text is available in the LICENSE file at the root of this project.
 *  This software is distributed WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

package ir.callvault.app.services.recording

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import ir.callvault.app.integrations.adb.AdbShell
import ir.callvault.app.server.RecorderBackend
import ir.callvault.app.utils.AppLogger

/**
 * The "Turn Wireless debugging on" button on the paused-recording notification.
 *
 * CallVault leaves a Wireless-debugging switch the user turned off alone by default (2026-09-14). This is the
 * user asking for it back in one tap, so it runs as a user request — the only way past that respect.
 */
class WirelessDebuggingActionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION) return
        val app = context.applicationContext
        val pending = goAsync()
        Thread {
            val on = try {
                AdbShell.asUserRequest { AdbShell.enableWirelessDebugging(app) }
            } finally {
                // Finish the broadcast as soon as the switch is written. The relaunch below can take the whole 24 s
                // launch budget, or queue behind another ADB user, and a receiver still pending that long is an ANR.
                // The keep-alive's foreground service keeps the process alive meanwhile.
                pending.finish()
            }
            AppLogger.i(TAG, "User asked to turn Wireless debugging back on: ${if (on) "on" else "refused (see the log above)"}")
            if (on) {
                runCatching { RecorderBackend.ensureRunning(app) }
                    .onFailure { AppLogger.w(TAG, "Could not start the recorder after turning Wireless debugging on: ${it.message}") }
                // Refresh the notification now; left to the next keep-alive tick it went on saying
                // "keeps failing to start" for ~15 s while the recorder was already back.
                runCatching { DaemonKeepAliveService.start(app) }
            }
        }.apply { isDaemon = true; name = "cv-wd-action" }.start()
    }

    companion object {
        private const val TAG = "CV:WdAction"
        private const val ACTION = "ir.callvault.app.action.TURN_WIRELESS_DEBUGGING_ON"

        fun pendingIntent(context: Context): PendingIntent = PendingIntent.getBroadcast(
            context,
            0,
            Intent(context, WirelessDebuggingActionReceiver::class.java).setAction(ACTION),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }
}
