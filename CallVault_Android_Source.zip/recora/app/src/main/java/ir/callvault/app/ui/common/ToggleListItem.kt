/*
 * CallVault: FOSS call recording, self-contained over embedded ADB
 *  Copyright (C) 2026-present kitsumed (Med)
 *  Copyright (C) 2026-present The CallVault Authors
 *  This software is licensed under the GNU General Public License v3 or later, with additional terms as permitted under Section 7.
 *  The full license text is available in the LICENSE file at the root of this project.
 *  This software is distributed WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

package ir.callvault.app.ui.common

import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.tooling.preview.Preview
import ir.callvault.app.ui.theme.CallVaultTheme

/** A list row with a switch. Tapping anywhere on the row toggles the switch.
 *
 * @param label           The text shown as the headline of the row.
 * @param checked         The current on/off state of the switch.
 * @param onCheckedChange Called with the new boolean when the user toggles.
 * @param modifier        Optional [Modifier] forwarded to the root [ListItem].
 * @param description     Optional text shown below the label.
 * @param enabled         Whether the switch and row are interactable.
 */
@Composable
fun ToggleListItem(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    description: String? = null,
    enabled: Boolean = true
) {
    val contentAlpha = if (enabled) 1f else 0.38f
    ListItem(
        // One toggleable node for the whole row, so TalkBack reads the label with the switch's state
        // ("…, Switch, On") instead of the label and an unlabelled switch as two stops.
        modifier        = modifier.toggleable(
            value = checked,
            enabled = enabled,
            role = Role.Switch,
            onValueChange = onCheckedChange,
        ),
        headlineContent = { Text(label, color = MaterialTheme.colorScheme.onSurface.copy(alpha = contentAlpha)) },
        supportingContent = if (description != null) {
            { Text(description, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = contentAlpha)) }
        } else null,
        // Display only (the row toggles). The minimum size keeps the 48dp slot a clickable Switch has.
        trailingContent = {
            Switch(
                checked = checked,
                onCheckedChange = null,
                enabled = enabled,
                modifier = Modifier.minimumInteractiveComponentSize(),
            )
        },
        colors          = ListItemDefaults.colors(containerColor = Color.Transparent)
    )
}

@Preview(showBackground = true)
@Composable
private fun PreviewToggleListItem() {
    CallVaultTheme(darkTheme = false) {
        Column() {
            ToggleListItem(
                label = "Example Checked Toggle",
                checked = true,
                onCheckedChange = {},
                description = "This is what a toggle list item looks like"
            )

            ToggleListItem(
                label = "Example Unchecked Toggle",
                checked = false,
                onCheckedChange = {},
                description = "This is what a toggle list item looks like"
            )

            ToggleListItem(
                label = "Example Disabled Toggle",
                checked = false,
                enabled = false,
                onCheckedChange = {},
                description = "This is what a toggle list item looks like"
            )
        }
    }
}
