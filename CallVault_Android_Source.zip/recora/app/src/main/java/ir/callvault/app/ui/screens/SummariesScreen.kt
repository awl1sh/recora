/*
 * CallVault: FOSS call recording, self-contained over embedded ADB
 *  Copyright (C) 2026-present The CallVault Authors
 *  This software is licensed under the GNU General Public License v3 or later, with additional terms as permitted under Section 7.
 *  The full license text is available in the LICENSE file at the root of this project.
 *  This software is distributed WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

package ir.callvault.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import ir.callvault.app.R
import ir.callvault.app.data.recordings.ImportedRecording
import ir.callvault.app.data.recordings.RecordingsRepository.RecordingItem
import ir.callvault.app.data.transcripts.LibraryRowActions
import ir.callvault.app.data.transcripts.PageSearch
import ir.callvault.app.data.transcripts.db.RecordingLabelEntry
import ir.callvault.app.data.transcripts.SummariesPage
import ir.callvault.app.data.transcripts.export.TranscriptFormat
import ir.callvault.app.ui.common.CvScaffold
import ir.callvault.app.ui.common.CvSectionHeader
import ir.callvault.app.ui.common.RecordingLabel
import ir.callvault.app.ui.common.SearchLine
import ir.callvault.app.ui.common.TranscriptAudio
import ir.callvault.app.ui.common.WorkProgressRing

/**
 * The Summaries page: every call a model has written up, and every one it is writing.
 *
 * ## What it shows, and why in that order
 *
 * The finished summaries are the page, and their count is exactly what the hub's card says —
 * [SummariesPage.Groups.ready] is the same set of rows
 * [ir.callvault.app.data.transcripts.LibraryCounts.summarised] counts, so the card and the page
 * agree by construction rather than by two queries that happen to match. Above them:
 *
 *  - **what is being summarised**, because a run is about ninety seconds of full CPU and gigabytes
 *    of memory that the user asked for, and unlike a transcription nothing anywhere else says so —
 *    there is no pill beside the title and no row state, because a summary has no database row
 *    until it succeeds;
 *  - **what failed**, because nothing retries a failed summary, so without a heading naming them a
 *    run that died is invisible for ever.
 *
 * ## What it does not show
 *
 * **No snippet of the summary.** A summary row carries its whole JSON document, so a first line
 * means reading and parsing every document on every visit to the page — cost that grows with how
 * much the user has summarised, on a screen they open to find something. Same argument, and the
 * same regression shape, as the Transcripts page's missing first line.
 *
 * **No "write it again" on a row.** Deciding a summary needs redoing means having read it and found
 * it wanting, and this list deliberately shows none of the words; a redo button one mis-tap from a
 * row would spend ninety seconds of full CPU replacing something the user never saw was wrong. The
 * button lives under the summary it would replace, which is the only place the judgement can be
 * made. **Stop is the opposite case and is offered here**: it needs no reading, it is always safe,
 * and a run somebody wants stopped is exactly the one they may not be able to find.
 *
 * @param groups     Already grouped; see [SummariesPage] for what is kept and why.
 * @param recordings The catalog, resolved to rows **once for the whole list** rather than per row.
 * @param listState  Hoisted by the caller: this page leaves composition on every section switch and
 *                   whenever a summary is opened over it, taking any place in the list with it.
 * @param onOpen     Opens the reading view — see the call site for why that rather than the
 *                   recording's own screen.
 * @param onShare    Sends one stored summary to the share sheet.
 * @param onSave     Writes one stored summary out as a file in the chosen format.
 * @param onDelete   Asks to delete one **summary**. The transcript it was written from and the
 *                   recording both stay; see
 *                   [ir.callvault.app.data.transcripts.LibraryRowActions].
 * @param selection  Multi-select for this page — see [LibrarySelectionUi]. Only a stored summary
 *                   can be picked: a run still in flight has no row to share or delete.
 * @param onStop     Stops whatever the summariser is doing. One stop for the whole queue, because
 *                   that is all there is: the engine serialises on a mutex and runs one at a time.
 */
@Composable
fun SummariesScreen(
    groups: SummariesPage.Groups,
    recordings: List<RecordingItem>,
    listState: LazyListState,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit,
    /** What the search line holds, and the stored summaries it found with their excerpts. */
    query: String,
    onQueryChange: (String) -> Unit,
    excerpts: Map<String, PageSearch.Excerpt>,
    /** What each recording was last called, for a row whose recording is not in [recordings] yet. */
    labels: Map<String, RecordingLabelEntry>,
    onOpen: (String) -> Unit,
    onShare: (String) -> Unit,
    onSave: (String, TranscriptFormat) -> Unit,
    onDelete: (String) -> Unit,
    selection: LibrarySelectionUi,
    onStop: () -> Unit,
    modifier: Modifier = Modifier,
    titleTrailing: (@Composable () -> Unit)? = null,
) {
    // Resolved once for the whole page rather than per row: a row that looked itself up would put a
    // walk of the recordings list behind every visible line of the screen.
    val byName = recordings.associateBy { it.displayName }

    CvScaffold(
        modifier = modifier.fillMaxSize(),
        title =
            if (selection.active) {
                pluralStringResource(
                    R.plurals.home_selected_count, selection.selected.size, selection.selected.size
                )
            } else {
                stringResource(R.string.home_summaries_title)
            },
        // Leaving selection comes first, exactly as on the recordings list and on Transcripts.
        onBack = if (selection.active) selection.onClear else onBack,
        titleTrailing = if (selection.active) null else titleTrailing,
        actions = {
            if (selection.active) {
                LibrarySelectionActions(selection)
                return@CvScaffold
            }
            IconButton(onClick = onOpenSettings) {
                Icon(
                    imageVector = Icons.Filled.Tune,
                    contentDescription = stringResource(R.string.home_open_settings),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = innerPadding.calculateTopPadding() + 8.dp,
                bottom = innerPadding.calculateBottomPadding() + 28.dp
            ),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // The "Select all" row, pinned at the top while selecting and hidden otherwise — sitting
            // directly over the rows whose ticks it drives.
            if (selection.active) {
                item {
                    LibrarySelectAllRow(
                        allSelected = selection.allSelected,
                        someSelected = selection.someSelected,
                        selectedCount = selection.selected.size,
                        onClick = selection.onSelectAll,
                    )
                }
            }
            // The search line at the head of the list, as on the other two pages. Only once there
            // is something to search — on an empty page it would be a field that can only ever find
            // nothing.
            val searching = query.isNotBlank()
            if (!selection.active && (searching || !groups.isEmpty)) {
                item {
                    SearchLine(
                        query = query,
                        onQueryChange = onQueryChange,
                        placeholder = stringResource(R.string.summaries_search_hint),
                    )
                }
            }

            if (groups.isEmpty) {
                item {
                    if (searching) {
                        LibrarySectionEmpty(
                            title = stringResource(R.string.search_no_matches_title),
                            hint = stringResource(R.string.search_no_matches_hint, query.trim()),
                        )
                    } else {
                        LibrarySectionEmpty(
                            title = stringResource(R.string.home_summaries_empty_title),
                            hint = stringResource(R.string.home_summaries_empty_hint),
                        )
                    }
                }
                return@LazyColumn
            }

            if (groups.working.isNotEmpty()) {
                item { WorkingHeader(onStop = onStop) }
                items(groups.working, key = { "working:" + it.displayName }) { working ->
                    SummaryRow(
                        displayName = working.displayName,
                        item = byName[working.displayName],
                        cached = labels[working.displayName],
                        // Never selectable: there is no summary row yet to share or delete, which is
                        // the asymmetry this whole page is built around.
                        selectionMode = selection.active,
                        // Nothing to open while the FIRST summary is being written — and a row that
                        // visibly accepts a tap and does nothing reads as the app having missed it.
                        // A rewrite is a different matter: its earlier summary is still readable,
                        // and that row is in the list below, where it opens.
                        onOpen = null,
                        trailing = { WorkProgressRing(percent = working.percent) },
                    )
                }
            }

            if (groups.failed.isNotEmpty()) {
                item { CvSectionHeader(text = stringResource(R.string.summaries_failed_header)) }
                item {
                    Text(
                        text = stringResource(R.string.summaries_failed_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 4.dp, bottom = 2.dp),
                    )
                }
                // No menu: a failed run left no summary row, so there is nothing to share, save or
                // delete. What it left is a work info, and Stop above is what clears that.
                summaryRows(
                    groups.failed,
                    byName,
                    onOpen,
                    menu = LibraryRowActions.NONE,
                    onShare,
                    onSave,
                    onDelete,
                    // Not selectable either, for the same reason it has no menu: a failed run left
                    // no row behind, so a bulk delete would have nothing of its to take.
                    selection = null,
                    selectionMode = selection.active,
                    labels = labels,
                )
            }

            item {
                Text(
                    text = stringResource(R.string.home_summaries_count, groups.ready.size),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 4.dp, top = 4.dp, bottom = 2.dp),
                )
            }
            summaryRows(
                groups.ready,
                byName,
                onOpen,
                menu = LibraryRowActions.forStoredSummary(),
                onShare,
                onSave,
                onDelete,
                selection = selection,
                selectionMode = selection.active,
                excerpts = excerpts,
                labels = labels,
            )
        }
    }
}

/**
 * One group of rows.
 *
 * A `LazyListScope` extension rather than a composable, so the rows stay individual list items: a
 * composable wrapping them would compose every row in the group at once, which is the whole point
 * of a lazy list on a library that can run to thousands of calls.
 */
private fun LazyListScope.summaryRows(
    displayNames: List<String>,
    byName: Map<String, RecordingItem>,
    onOpen: (String) -> Unit,
    menu: LibraryRowActions.Menu,
    onShare: (String) -> Unit,
    onSave: (String, TranscriptFormat) -> Unit,
    onDelete: (String) -> Unit,
    /** Null where the group's rows cannot be picked, which is also where they have no menu. */
    selection: LibrarySelectionUi?,
    selectionMode: Boolean,
    excerpts: Map<String, PageSearch.Excerpt> = emptyMap(),
    labels: Map<String, RecordingLabelEntry> = emptyMap(),
) {
    items(displayNames, key = { it }) { displayName ->
        SummaryRow(
            displayName = displayName,
            item = byName[displayName],
            cached = labels[displayName],
            onOpen = { onOpen(displayName) },
            excerpt = excerpts[displayName],
            selectionMode = selectionMode,
            selected = selection?.selected?.contains(displayName) == true,
            onToggleSelected = selection?.let { picker -> { picker.onToggle(displayName) } },
            trailing = if (menu.isEmpty) null else {
                {
                    LibraryRowMenu(
                        menu = menu,
                        formats = LibraryRowActions.formatsFor(LibraryRowActions.Page.Summaries),
                        onShare = { onShare(displayName) },
                        onSave = { format -> onSave(displayName, format) },
                        onDelete = { onDelete(displayName) },
                    )
                }
            },
        )
    }
}

/**
 * One row, named the way every other list names the same call.
 *
 * [item] is null when the summary has outlived its recording, which is rare but real: the two are
 * separate databases and the delete cascade is called by hand. **The row is still drawn** — with the
 * file's own name and no date — because the hub's card counts rows in the summaries table and cannot
 * see the recordings catalog, so a row dropped here is a number the user can catch the app lying
 * about by counting. It is also the honest reading of what it is: the summary really is still there
 * and still readable, and only the audio has gone.
 */
@Composable
private fun SummaryRow(
    displayName: String,
    item: RecordingItem?,
    onOpen: (() -> Unit)?,
    cached: RecordingLabelEntry? = null,
    trailing: (@Composable () -> Unit)? = null,
    selectionMode: Boolean = false,
    selected: Boolean = false,
    onToggleSelected: (() -> Unit)? = null,
    excerpt: PageSearch.Excerpt? = null,
) = LibraryNameRow(
    title = libraryRowTitle(item, cached, displayName),
    subtitle = libraryRowSubtitle(item, cached),
    // A missing row is the audio being gone, which is what the badge says first: it changes what the
    // row can do. Where the audio IS there, "imported" is read from the NAME rather than from the
    // row, because saying nothing would make an import read as a call whose details all failed to
    // parse. One badge, never two — see TranscriptAudio.badgeFor.
    badge = TranscriptAudio.badgeFor(
        hasAudio = item != null,
        isImported = ImportedRecording.isImported(displayName),
    ),
    onOpen = onOpen,
    trailing = trailing,
    selectionMode = selectionMode,
    selected = selected,
    onToggleSelected = onToggleSelected,
    excerpt = excerpt,
)

/**
 * The heading over what is being summarised, with the way to stop it.
 *
 * Stop is always offered here, where the Transcripts page offers it only while a worker is actually
 * running. The difference is what the button does: this one cancels the unique work as well as
 * aborting the engine, so it stops a queued summary as surely as a running one — and a summary that
 * is merely queued is still a phone about to spend ninety seconds at full CPU.
 */
@Composable
private fun WorkingHeader(onStop: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CvSectionHeader(
            text = stringResource(R.string.summaries_working_header),
            modifier = Modifier.weight(1f),
        )
        TextButton(onClick = onStop) {
            Text(
                text = stringResource(R.string.summary_card_stop),
                // Stated, not defaulted: a TextButton takes its content colour from the primary
                // role, and this scheme resolves several of M3's own roles to CoralDeep — the trap
                // already commented on the scroll-to-top button and the progress ring.
                color = MaterialTheme.colorScheme.primary,
            )
        }
        Spacer(Modifier.padding(end = 4.dp))
    }
}
