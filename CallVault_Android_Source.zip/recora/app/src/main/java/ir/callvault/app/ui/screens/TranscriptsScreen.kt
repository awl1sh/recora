/*
 * CallVault: FOSS call recording, self-contained over embedded ADB
 *  Copyright (C) 2026-present The CallVault Authors
 *  This software is licensed under the GNU General Public License v3 or later, with additional terms as permitted under Section 7.
 *  The full license text is available in the LICENSE file at the root of this project.
 *  This software is distributed WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

package ir.callvault.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.automirrored.filled.Notes
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ir.callvault.app.R
import ir.callvault.app.data.recordings.ImportedRecording
import ir.callvault.app.data.recordings.RecordingsRepository.RecordingItem
import ir.callvault.app.data.transcripts.LibraryRowActions
import ir.callvault.app.data.transcripts.PageSearch
import ir.callvault.app.data.transcripts.TranscriptStatus
import ir.callvault.app.data.transcripts.TranscriptsPage
import ir.callvault.app.data.transcripts.db.RecordingLabelEntry
import ir.callvault.app.data.transcripts.db.TranscriptEntry
import ir.callvault.app.data.transcripts.export.TranscriptFormat
import ir.callvault.app.ui.common.CvCard
import ir.callvault.app.ui.common.CvScaffold
import ir.callvault.app.ui.common.CvSectionHeader
import ir.callvault.app.ui.common.RecordingLabel
import ir.callvault.app.ui.common.SearchLine
import ir.callvault.app.ui.common.TranscribingPillState
import ir.callvault.app.ui.common.TranscriptActionButton
import ir.callvault.app.ui.common.TranscriptAudio

/**
 * The Transcripts page: everything transcribed, and everything on its way to being.
 *
 * ## What it shows, and why in that order
 *
 * The finished transcripts are the page, and their count is exactly what the hub's card says —
 * [TranscriptsPage.Groups.ready] is the same DONE rows [ir.callvault.app.data.transcripts.LibraryCounts.transcribed]
 * counts, so the card and the page agree by construction rather than by two queries that happen to
 * match. Above them sit the two things the app otherwise never says out loud:
 *
 *  - **what is being transcribed**, because a run is minutes of CPU the user asked for and the only
 *    other sign of it is a pill beside a title on whatever screen they happen to be on;
 *  - **what failed**, because the scheduler deliberately never retries a FAILED row — so without a
 *    heading that names them, a transcription that died is invisible for ever unless the user
 *    scrolls the recordings list looking for a red icon.
 *
 * ## What it does not show
 *
 * **No snippet of the words.** It was wanted, and it is not cheap: the transcripts table holds no
 * text, so the only way to a first line is a group-by across every segment of every call — cost that
 * grows with how much the user has transcribed, on a screen they open to find something. That is the
 * exact shape of the list-load regression that made freshly recorded calls look missing. The row says
 * who the call was with and when, which is what recognises it.
 *
 * ## Why import lives here
 *
 * An imported file is not a call and has no business on a list of calls; the only reason to bring
 * one in is to read it. So the way in sits on the page that shows what has been read — above the
 * groups, and above the empty state too, because someone who has never transcribed anything is
 * precisely the person for whom importing is the answer.
 *
 * @param groups     Already grouped; see [TranscriptsPage] for what is kept and why.
 * @param recordings The catalog, resolved to rows **once for the whole list** rather than per row.
 *                   A transcript with no row in it is drawn from its own file name; see
 *                   [transcriptRows].
 * @param transcribing What the queue is doing, the same state the title pill reads. It supplies the
 *                   percentage inside a running row's ring, and its being anything other than
 *                   Hidden is what makes Stop worth offering.
 * @param listState  Hoisted by the caller: this page leaves composition on every section switch and
 *                   whenever a transcript is opened over it, taking any place in the list with it.
 * @param onOpenQueue Opens the queue sheet, which owns the Stop.
 * @param onOpen     Read a finished transcript.
 * @param onRetry    Try a failed one again.
 * @param onOpenAudio Opens a recording's own screen — used by the waiting group, where the audio is
 *                   still there and playing, sharing or deleting it are the other things to do.
 * @param onShare    Sends one finished transcript's words to the share sheet.
 * @param onSave     Writes one finished transcript out as a file in the chosen format.
 * @param onDelete   Asks to delete one transcript's **text**. Never the recording — see
 *                   [ir.callvault.app.data.transcripts.LibraryRowActions] for why a page about
 *                   words does not offer to destroy audio.
 * @param selection  Multi-select for this page — see [LibrarySelectionUi]. While it is active the
 *                   bar becomes a count and two bulk actions, the import card is hidden (importing
 *                   is not something anyone does in the middle of picking rows), and only finished
 *                   transcripts can be picked: those are the rows a bulk share or delete means
 *                   anything for.
 * @param onImport   Raises the file picker; the flag is true for "Transcribe only".
 * @param importing  True while a chosen file is being copied and checked. The card says so and
 *                   stops accepting taps: the copy is not instant for a long recording, and a second
 *                   picker opened over the first would import the same file twice.
 */
@Composable
fun TranscriptsScreen(
    groups: TranscriptsPage.Groups,
    recordings: List<RecordingItem>,
    transcribing: TranscribingPillState,
    listState: LazyListState,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit,
    /** What the search line holds, and the readable transcripts it found with their excerpts. */
    query: String,
    onQueryChange: (String) -> Unit,
    excerpts: Map<String, PageSearch.Excerpt>,
    /** What each recording was last called, for a row whose recording is not in [recordings] yet. */
    labels: Map<String, RecordingLabelEntry>,
    onOpenQueue: () -> Unit,
    onOpen: (String) -> Unit,
    onRetry: (String) -> Unit,
    onOpenAudio: (String) -> Unit,
    onShare: (String) -> Unit,
    onSave: (String, TranscriptFormat) -> Unit,
    onDelete: (String) -> Unit,
    selection: LibrarySelectionUi,
    onImport: (transcribeOnly: Boolean) -> Unit,
    importing: Boolean,
    modifier: Modifier = Modifier,
    titleTrailing: (@Composable () -> Unit)? = null,
) {
    // Resolved once for the whole page rather than per row: a row that looked itself up would put a
    // walk of the recordings list behind every visible line of the screen.
    val byName = recordings.associateBy { it.displayName }
    var showImportSheet by rememberSaveable { mutableStateOf(false) }
    if (showImportSheet) {
        ImportChoiceSheet(
            onDismiss = { showImportSheet = false },
            onChoose = { transcribeOnly ->
                showImportSheet = false
                onImport(transcribeOnly)
            },
        )
    }

    CvScaffold(
        modifier = modifier.fillMaxSize(),
        title =
            if (selection.active) {
                pluralStringResource(
                    R.plurals.home_selected_count, selection.selected.size, selection.selected.size
                )
            } else {
                stringResource(R.string.home_transcripts_title)
            },
        // Leaving selection comes first, exactly as on the recordings list: while rows are picked
        // the arrow has to undo that rather than the navigation, or there is no way out but acting.
        onBack = if (selection.active) selection.onClear else onBack,
        // Nothing beside the title while selecting: the title IS a count, and a pill next to it
        // would read as part of it.
        titleTrailing = if (selection.active) null else titleTrailing,
        actions = {
            if (selection.active) {
                LibrarySelectionActions(selection)
                return@CvScaffold
            }
            IconButton(onClick = onOpenSettings) {
                Icon(
                    imageVector = Icons.Filled.Tune,
                    contentDescription = stringResource(R.string.home_open_settings),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        // The way in for imports. It replaced a card that took a fifth of the page to explain one
        // button; the two choices are explained on the sheet it opens, when they are being made.
        // Not while selecting, where every tap on the page has become a toggle.
        floatingActionButton = {
            if (!selection.active) {
                ImportFab(
                    importing = importing,
                    expanded = !listState.isScrollInProgress,
                    onClick = { showImportSheet = true },
                )
            }
        },
    ) { innerPadding ->
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = innerPadding.calculateTopPadding() + 8.dp,
                // Room under the last row for the floating Import button, so it never covers it at rest.
                bottom = innerPadding.calculateBottomPadding() + 96.dp
            ),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // The "Select all" row, pinned at the top while selecting and hidden otherwise. Above the
            // search and import cards (both of which hide during selection anyway), so it sits
            // directly over the rows whose ticks it drives.
            if (selection.active) {
                item {
                    LibrarySelectAllRow(
                        allSelected = selection.allSelected,
                        someSelected = selection.someSelected,
                        selectedCount = selection.selected.size,
                        onClick = selection.onSelectAll,
                    )
                }
            }
            // Before the empty-state branch below, which returns early. An empty Transcripts page is
            // exactly where importing needs to be offered — it is one of the two answers to "there
            // is nothing here yet", and the other one is on a different screen.
            // Not while selecting: bringing a new file in is not something anybody does in the
            // middle of picking rows, and the card carries two live buttons where every other tap on
            // the page has become a toggle.
            // The search line above the import card: a word search over what is here, the rows it
            // finds each carrying the words around the match. Only once there is something to
            // search — on an empty page it would be a field that can only ever find nothing.
            val searching = query.isNotBlank()
            if (!selection.active && (searching || !groups.isEmpty)) {
                item {
                    SearchLine(
                        query = query,
                        onQueryChange = onQueryChange,
                        placeholder = stringResource(R.string.transcripts_search_hint),
                    )
                }
            }

            if (groups.isEmpty) {
                item {
                    if (searching) {
                        LibrarySectionEmpty(
                            title = stringResource(R.string.search_no_matches_title),
                            hint = stringResource(R.string.search_no_matches_hint, query.trim()),
                        )
                    } else {
                        LibrarySectionEmpty(
                            title = stringResource(R.string.home_transcripts_empty_title),
                            hint = stringResource(R.string.home_transcripts_empty_hint),
                        )
                    }
                }
                return@LazyColumn
            }

            // Above everything, including what is running: this is audio sitting on the phone that
            // the user asked to have read and that nothing is currently reading. It is the one group
            // on this page that needs an action rather than attention.
            if (groups.waiting.isNotEmpty()) {
                item { CvSectionHeader(text = stringResource(R.string.transcripts_waiting_header)) }
                item {
                    Text(
                        text = stringResource(R.string.transcripts_waiting_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 4.dp, bottom = 2.dp),
                    )
                }
                waitingRows(
                    names = groups.waiting,
                    byName = byName,
                    onTranscribe = onRetry,
                    onOpen = onOpenAudio,
                    selectionMode = selection.active,
                )
            }

            if (groups.working.isNotEmpty()) {
                item {
                    QueueHeader(
                        isRunning = transcribing != TranscribingPillState.Hidden,
                        onOpenQueue = onOpenQueue,
                    )
                }
                transcriptRows(
                    entries = groups.working,
                    byName = byName,
                    // Nothing to open: the words do not exist yet. A card that took a tap and did
                    // nothing would read as the app having missed it.
                    onOpen = null,
                    onRetry = onRetry,
                    onShare = onShare,
                    onSave = onSave,
                    onDelete = onDelete,
                    selection = selection,
                labels = labels,
                    percentFor = transcribing::percentFor,
                )
            }

            if (groups.failed.isNotEmpty()) {
                item { CvSectionHeader(text = stringResource(R.string.transcripts_failed_header)) }
                item {
                    Text(
                        text = stringResource(R.string.transcripts_failed_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 4.dp, bottom = 2.dp),
                    )
                }
                transcriptRows(
                    entries = groups.failed,
                    byName = byName,
                    // The whole card retries, as well as the icon on it: a row that says it failed
                    // and offers one 40dp target to act on is a small target for the one thing the
                    // user opened this heading to do.
                    onOpen = onRetry,
                    onRetry = onRetry,
                    onShare = onShare,
                    onSave = onSave,
                    onDelete = onDelete,
                    selection = selection,
                labels = labels,
                    percentFor = { 0 },
                )
            }

            item {
                Text(
                    text = stringResource(R.string.home_transcripts_count, groups.ready.size),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 4.dp, top = 4.dp, bottom = 2.dp),
                )
            }
            transcriptRows(
                entries = groups.ready,
                byName = byName,
                onOpen = onOpen,
                onRetry = onRetry,
                onShare = onShare,
                onSave = onSave,
                onDelete = onDelete,
                selection = selection,
                labels = labels,
                percentFor = { 0 },
                excerpts = excerpts,
            )
        }
    }
}

/**
 * The rows for audio that is waiting to be read, with the way to start it.
 *
 * Separate from [transcriptRows] because these have no transcript entry to draw a status from — that
 * is the whole reason they are here. The trailing button is therefore always
 * [TranscriptStatus.NONE]'s: offer to transcribe.
 *
 * Tapping the card opens the recording's own screen instead, which is where playing it, sharing it
 * and deleting it already are. A file the user can see but only transcribe is a file they cannot get
 * rid of, and this group exists precisely for the cases where they may want to.
 */
private fun LazyListScope.waitingRows(
    names: List<String>,
    byName: Map<String, RecordingItem>,
    onTranscribe: (String) -> Unit,
    onOpen: (String) -> Unit,
    /**
     * True while the page is selecting. These rows are never selectable — there is no text to share
     * or delete yet — so they simply go inert, rather than opening a screen out of the middle of a
     * sweep down the list.
     */
    selectionMode: Boolean,
) {
    items(names, key = { it }) { displayName ->
        val item = byName[displayName]
        LibraryNameRow(
            title = item?.let { RecordingLabel.of(it) } ?: RecordingLabel.forName(displayName),
            subtitle = item?.displayDate,
            // Always Imported, never Text only: this group IS the files still waiting on the phone,
            // so their audio is by definition there — that is what there is to transcribe.
            badge = TranscriptAudio.RowBadge.Imported,
            onOpen = { onOpen(displayName) },
            selectionMode = selectionMode,
            trailing = {
                TranscriptActionButton(
                    status = TranscriptStatus.NONE,
                    percent = 0,
                    onTranscribe = { onTranscribe(displayName) },
                    onOpen = { onOpen(displayName) },
                    onRetry = { onTranscribe(displayName) },
                )
            },
        )
    }
}

/**
 * One group of rows.
 *
 * A `LazyListScope` extension rather than a composable, so the rows stay individual list items: a
 * composable wrapping them would compose every row in the group at once, which is the whole point of
 * a lazy list on a library that can run to thousands of calls.
 *
 * Keyed on the display name rather than the entry, because the entry's state changes as a
 * transcription progresses and a key that changed would throw the row away and rebuild it.
 */
private fun LazyListScope.transcriptRows(
    entries: List<TranscriptEntry>,
    byName: Map<String, RecordingItem>,
    onOpen: ((String) -> Unit)?,
    onRetry: (String) -> Unit,
    onShare: (String) -> Unit,
    onSave: (String, TranscriptFormat) -> Unit,
    onDelete: (String) -> Unit,
    selection: LibrarySelectionUi,
    percentFor: (String) -> Int,
    excerpts: Map<String, PageSearch.Excerpt> = emptyMap(),
    labels: Map<String, RecordingLabelEntry> = emptyMap(),
) {
    items(entries, key = { it.displayName }) { entry ->
        // Null when the transcript has outlived its recording, which is rare but real: the two are
        // separate databases and the delete cascade is called by hand. The row is still drawn — see
        // TranscriptsPage.group for why dropping it made the hub's count a lie — with the file's own
        // name and no date, so what is missing shows rather than being papered over.
        val item = byName[entry.displayName]
        val status = TranscriptStatus.of(entry.state)
        val isDone = status == TranscriptStatus.DONE
        LibraryNameRow(
            title = libraryRowTitle(item, labels[entry.displayName], entry.displayName),
            subtitle = libraryRowSubtitle(item, labels[entry.displayName]),
            // A missing row is the audio being gone, which is what the badge says first: it changes
            // what the row can do. Where the audio IS there, "imported" is read from the NAME rather
            // than from the row, because saying nothing would make an import read as a call whose
            // details all failed to parse.
            badge = TranscriptAudio.badgeFor(
                hasAudio = item != null,
                isImported = ImportedRecording.isImported(entry.displayName),
            ),
            onOpen = onOpen?.let { open -> { open(entry.displayName) } },
            selectionMode = selection.active,
            selected = entry.displayName in selection.selected,
            // Only a finished transcript can be picked. A bulk share or delete over a queued, failed
            // or waiting row would mean nothing — there are no words there to send or destroy.
            onToggleSelected = if (isDone) ({ selection.onToggle(entry.displayName) }) else null,
            excerpt = excerpts[entry.displayName],
            // A finished transcript needs no "open" icon — the card is the affordance, and a button
            // on a card that opens says it twice — so its slot carries the overflow menu instead.
            // Every other state keeps the one action it has: transcribe, in progress, or retry.
            trailing = if (isDone) {
                {
                    LibraryRowMenu(
                        menu = LibraryRowActions.forTranscript(entry.state, hasAudio = item != null),
                        formats = LibraryRowActions.formatsFor(LibraryRowActions.Page.Transcripts),
                        onShare = { onShare(entry.displayName) },
                        onSave = { format -> onSave(entry.displayName, format) },
                        onDelete = { onDelete(entry.displayName) },
                    )
                }
            } else {
                {
                    TranscriptActionButton(
                        status = status,
                        percent = percentFor(entry.displayName),
                        onTranscribe = { onRetry(entry.displayName) },
                        onOpen = { onOpen?.invoke(entry.displayName) },
                        onRetry = { onRetry(entry.displayName) },
                    )
                }
            },
        )
    }
}

/**
 * The floating Import button. Shrinks to a round + while the list is moving so it covers less of the
 * rows, and grows back when it stops.
 *
 * While a chosen file is being copied it says so and takes no taps: the copy is not instant for a
 * long recording, and a second picker raised over the first would import the same file twice.
 */
@Composable
private fun ImportFab(importing: Boolean, expanded: Boolean, onClick: () -> Unit) {
    ExtendedFloatingActionButton(
        onClick = { if (!importing) onClick() },
        expanded = expanded || importing,
        icon = {
            if (importing) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp,
                    // Stated, not defaulted: several M3 roles resolve to coral in this scheme.
                    color = MaterialTheme.colorScheme.onPrimary,
                )
            } else {
                Icon(Icons.Filled.Add, contentDescription = null)
            }
        },
        text = {
            Text(stringResource(if (importing) R.string.transcripts_import_working else R.string.transcripts_import_fab))
        },
        containerColor = MaterialTheme.colorScheme.primary,
        contentColor = MaterialTheme.colorScheme.onPrimary,
    )
}

/** The two ways to import, each explained in one line, shown when the Import button is tapped. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ImportChoiceSheet(onDismiss: () -> Unit, onChoose: (transcribeOnly: Boolean) -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Text(
            text = stringResource(R.string.transcripts_import_title),
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(start = 24.dp, end = 24.dp, bottom = 8.dp),
        )
        ImportChoiceRow(
            icon = Icons.Filled.LibraryMusic,
            title = stringResource(R.string.import_sheet_keep),
            hint = stringResource(R.string.import_sheet_keep_hint),
            onClick = { onChoose(false) },
        )
        ImportChoiceRow(
            icon = Icons.AutoMirrored.Filled.Notes,
            title = stringResource(R.string.import_sheet_transcript_only),
            hint = stringResource(R.string.import_sheet_transcript_only_hint),
            onClick = { onChoose(true) },
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ImportChoiceRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    hint: String,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface)
            Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/**
 * The heading over what is being transcribed, with the way to stop it.
 *
 * Stop appears only while something is actually running. A queue with nothing in hand — tapped
 * recordings waiting for a worker that has not started — has nothing to stop, and a button that
 * cancels nothing is worse than no button. It opens the queue sheet rather than stopping here, so
 * there is one Stop in the app and it is the one that also releases the row it was working on.
 */
@Composable
private fun QueueHeader(isRunning: Boolean, onOpenQueue: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CvSectionHeader(
            text = stringResource(R.string.transcripts_working_header),
            modifier = Modifier.weight(1f),
        )
        if (isRunning) {
            TextButton(onClick = onOpenQueue) {
                Text(
                    text = stringResource(R.string.transcribing_sheet_stop),
                    // Stated, not defaulted: a TextButton takes its content colour from the primary
                    // role, and this scheme resolves several of M3's own roles to CoralDeep — the
                    // trap already commented on the scroll-to-top button and the progress ring.
                    color = MaterialTheme.colorScheme.primary,
                )
            }
        }
        Spacer(Modifier.padding(end = 4.dp))
    }
}
