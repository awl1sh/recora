/*
 * CallVault: FOSS call recording, self-contained over embedded ADB
 *  Copyright (C) 2026-present The CallVault Authors
 *  This software is licensed under the GNU General Public License v3 or later, with additional terms as permitted under Section 7.
 *  The full license text is available in the LICENSE file at the root of this project.
 *  This software is distributed WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

package ir.callvault.app.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TriStateCheckbox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.state.ToggleableState
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import ir.callvault.app.R
import ir.callvault.app.data.recordings.RecordingsRepository.RecordingItem
import ir.callvault.app.data.transcripts.PageSearch
import ir.callvault.app.data.transcripts.db.RecordingLabelEntry
import ir.callvault.app.ui.common.BidiText
import ir.callvault.app.ui.common.CvCard
import ir.callvault.app.ui.common.ImportedBadge
import ir.callvault.app.ui.common.RecordingLabel
import ir.callvault.app.ui.common.TextOnlyBadge
import ir.callvault.app.ui.common.TranscriptAudio

/**
 * The row every library list is built from.
 *
 * Shared by Transcripts and Summaries rather than copied into each, so a call carries one label
 * everywhere and the things this row gets right — the bidi isolation, the fixed trailing slot, the
 * "imported" badge — cannot be remembered in one list and forgotten in the next.
 *
 * **It takes a name, not a catalog row, and that is the point.** A transcript or a summary can
 * outlive its recording — the two are separate databases and the delete cascade is called by hand —
 * and such a row is still worth drawing, because the text is still readable. The caller passes what
 * it knows: the file's own name and no date rather than an invented one. What is missing is the
 * audio, which the badge now says outright rather than leaving to be inferred from a missing date.
 */
@Composable
internal fun LibraryNameRow(
    title: String,
    subtitle: String?,
    /**
     * The one badge beside the title. Here rather than at each call site so that Transcripts and
     * Summaries cannot disagree about what a row says, and so that the next list built on this row
     * gets it without anyone remembering.
     *
     * One, never two: the trailing slot is a fixed width and the title already ellipsises, so a
     * second pill would be paid for out of the name. [TranscriptAudio.badgeFor] decides which.
     */
    badge: TranscriptAudio.RowBadge = TranscriptAudio.RowBadge.None,
    onOpen: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
    /**
     * True while the page is in multi-select, whether or not THIS row can be picked.
     *
     * A row that cannot be picked goes inert for the duration rather than keeping its ordinary tap.
     * The alternative was measured against the gesture the page is in: while building a selection,
     * a tap that started a transcription — or opened a screen — would be the app doing something
     * nobody asked for, out of the middle of a sweep down a list.
     */
    selectionMode: Boolean = false,
    selected: Boolean = false,
    /** Null on a row that cannot be selected, which is also what makes long-press do nothing there. */
    onToggleSelected: (() -> Unit)? = null,
    /**
     * Why this row is in a search result: the words around the match, the match itself in bold.
     * Drawn under the subtitle in the direction of its own text, since a Hebrew excerpt under an
     * English file name is the common case rather than the odd one.
     */
    excerpt: PageSearch.Excerpt? = null,
) {
    val selectable = onToggleSelected != null

    CvCard(
        onClick = when {
            selectionMode && selectable -> onToggleSelected
            selectionMode -> null
            else -> onOpen
        },
        // Long-press is what ENTERS selection, so it is live whether or not selection is already on
        // — the same grammar the recordings list uses, and the one the platform trains people in.
        onLongClick = onToggleSelected,
        color = if (selected) {
            // primaryContainer, NOT secondaryContainer: the secondary role in this theme is
            // CoralDeep, so a selected row came out maroon on the recordings list and read as an
            // error or a pending deletion. The note is repeated here because the trap is the theme's,
            // not that screen's.
            MaterialTheme.colorScheme.primaryContainer
        } else {
            MaterialTheme.colorScheme.surface
        },
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        // weight(1f, fill = false) so the badge keeps its width and the TITLE is
                        // what ellipsises. The other way round the badge would be the thing that
                        // truncated, and half a word saying where a row came from says nothing.
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    when (badge) {
                        TranscriptAudio.RowBadge.None -> Unit
                        TranscriptAudio.RowBadge.Imported -> {
                            Spacer(Modifier.width(8.dp))
                            ImportedBadge()
                        }
                        TranscriptAudio.RowBadge.TextOnly -> {
                            Spacer(Modifier.width(8.dp))
                            TextOnlyBadge()
                        }
                    }
                }
                subtitle?.let { line ->
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = line,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                excerpt?.let { found ->
                    Spacer(Modifier.height(4.dp))
                    val direction = if (BidiText.isRtl(found.text)) LayoutDirection.Rtl else LayoutDirection.Ltr
                    CompositionLocalProvider(LocalLayoutDirection provides direction) {
                        Text(
                            text = buildAnnotatedString {
                                append(found.text)
                                if (found.matchEnd > found.matchStart) {
                                    addStyle(SpanStyle(fontWeight = FontWeight.Bold), found.matchStart, found.matchEnd)
                                }
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }
            // The tick takes the slot while selecting, so a row shows what a tap would do to it
            // rather than an action it is no longer offering.
            val slot: (@Composable () -> Unit)? = when {
                selectionMode && selectable -> ({ SelectionTick(selected = selected) })
                selectionMode -> null
                else -> trailing
            }
            if (slot != null) {
                Spacer(Modifier.width(12.dp))
                Box(modifier = Modifier.size(TRAILING_SLOT), contentAlignment = Alignment.Center) {
                    slot()
                }
            }
        }
    }
}

/**
 * What a library row is called and dated, in order of what is known: the recording in the list,
 * else what it was last called ([RecordingLabelEntry], while the list is still loading or the audio
 * is gone), else the file name alone. A cached label that IS the file name defers to [RecordingLabel.forName],
 * which knows how to read an import's name out of it.
 */
internal fun libraryRowTitle(item: RecordingItem?, cached: RecordingLabelEntry?, displayName: String): String =
    RecordingLabel.of(item)
        ?: cached?.label?.takeUnless { it == displayName }?.let(BidiText::isolate)
        ?: RecordingLabel.forName(displayName)

/** The date line under a library row, from the list if it is there, else from what was last known. */
internal fun libraryRowSubtitle(item: RecordingItem?, cached: RecordingLabelEntry?): String? =
    item?.displayDate ?: cached?.subtitle

/**
 * The trailing slot's size, fixed rather than wrapped.
 *
 * TranscriptActionButton is an icon button at one size and a progress ring at another, and a slot
 * that measured its content would move the row's text sideways every time a transcription started or
 * finished — in a list where the rows above it are doing the same.
 */
private val TRAILING_SLOT = 40.dp

/** Whether this row is in the selection, drawn where its action would otherwise be. */
@Composable
private fun SelectionTick(selected: Boolean) {
    Icon(
        imageVector = if (selected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
        contentDescription = null,
        // Stated: the teal the recordings list ticks with, not a role that resolves to CoralDeep.
        tint = if (selected) MaterialTheme.colorScheme.primary
               else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(22.dp),
    )
}

/**
 * The "Select all" row, pinned at the top of a library list while selecting.
 *
 * Shown only in selection mode — the caller gates it. Replaces the old app-bar select-all icon, which
 * read as just one more unlabelled action beside Share and Delete. Its tri-state box lines up with the
 * per-row ticks directly beneath it: filled when every visible selectable row is picked, a dash when
 * some are, empty when none. A tap picks them all; a tap when all are already picked clears the
 * selection but **stays in selection mode** (only the back arrow leaves).
 *
 * Shared by all three lists so the recordings, transcripts and summaries pages cannot drift apart on
 * what it says or how it behaves.
 */
@Composable
internal fun LibrarySelectAllRow(
    allSelected: Boolean,
    someSelected: Boolean,
    selectedCount: Int,
    onClick: () -> Unit,
) {
    CvCard(
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(
                        if (allSelected) R.string.selection_clear_all else R.string.selection_select_all
                    ),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                if (selectedCount > 0) {
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = pluralStringResource(
                            R.plurals.home_selected_count, selectedCount, selectedCount
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            Box(modifier = Modifier.size(TRAILING_SLOT), contentAlignment = Alignment.Center) {
                TriStateCheckbox(
                    state = when {
                        allSelected -> ToggleableState.On
                        someSelected -> ToggleableState.Indeterminate
                        else -> ToggleableState.Off
                    },
                    // The CvCard owns the tap; the box only shows state. Stated primary tint, not a
                    // role that resolves to CoralDeep in this theme.
                    onClick = null,
                    colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary),
                )
            }
        }
    }
}

/** Says what would put something here, rather than only that there is nothing. */
@Composable
internal fun LibrarySectionEmpty(title: String, hint: String) {
    CvCard(contentPadding = PaddingValues(20.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = hint,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
